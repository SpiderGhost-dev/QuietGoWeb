/* QuietGo marketing JS — wordmark coloring, smooth scroll, reveal */

(() => {
  const SKIP_TAGS = new Set(['SCRIPT','STYLE','NOSCRIPT','CODE','PRE','TEXTAREA','IFRAME']);

  // ----- 1) Wordmark enforcer: "QuietGo" => spans with brand colors
  function brandWordmark(root=document.body){
    try{
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode(node){
          if(!node.nodeValue || !node.nodeValue.includes('QuietGo')) return NodeFilter.FILTER_REJECT;
          const p = node.parentElement;
          if(!p || SKIP_TAGS.has(p.tagName)) return NodeFilter.FILTER_REJECT;
          if(p.closest('.qg') || p.dataset.qgSkip === '1') return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      });
      const nodes = [];
      while(walker.nextNode()) nodes.push(walker.currentNode);

      nodes.forEach(node => {
        const html = node.nodeValue.replace(/QuietGo/g,
          '<span class="qg"><span class="qg-quiet">Quiet</span><span class="qg-go">Go</span></span>');
        const span = document.createElement('span');
        span.innerHTML = html;
        node.parentNode.replaceChild(span, node);
      });
    }catch(e){ /* silent */ }
  }

  // Run once on ready, and once more after a tick for late content
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { brandWordmark(); setTimeout(brandWordmark, 150); });
  } else { brandWordmark(); setTimeout(brandWordmark, 150); }

  // ----- 2) Smooth scroll for internal anchors
  function onAnchorClick(e){
    const a = e.currentTarget;
    const href = a.getAttribute('href');
    if (!href || !href.startsWith('#')) return;
    const target = document.querySelector(href);
    if (!target) return;
    e.preventDefault();
    target.scrollIntoView({behavior:'smooth', block:'start'});
    history.replaceState(null, '', href);
  }
  document.addEventListener('click', (e)=>{
    const a = e.target.closest('a[href^="#"]');
    if (a) onAnchorClick(e);
  });

  // ----- 3) Reveal on scroll (respect reduced-motion)
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!prefersReduced && 'IntersectionObserver' in window){
    const obs = new IntersectionObserver((entries)=>{
      for(const ent of entries){
        if(ent.isIntersecting){
          ent.target.classList.add('reveal-in');
          obs.unobserve(ent.target);
        }
      }
    }, {threshold: 0.12});
    const candidates = [
      ...document.querySelectorAll('section'),
      ...document.querySelectorAll('.p-5, .card, .btn')
    ];
    candidates.forEach(el=>{
      if(!el.classList.contains('reveal')) el.classList.add('reveal');
      obs.observe(el);
    });
  }

  // ----- 4) Android waitlist hook (links to "#waitlist")
  const waitlistEl = document.querySelector('a[href="#waitlist"]');
  if (waitlistEl){
    waitlistEl.addEventListener('click', (e)=>{
      e.preventDefault();
      window.dispatchEvent(new CustomEvent('qg:waitlist'));
    });
  }
})();
