
// ENHANCED INTERACTIVITY AND ANIMATIONS FOR SALES CONVERSION
document.addEventListener('DOMContentLoaded', function() {
    console.log('Enhanced interactivity loaded!');

    // Add shake effect to buttons on hover
    const buttons = document.querySelectorAll('.btn, button, a[class*="btn"]');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.animation = 'shake 0.5s ease-in-out';
        });

        button.addEventListener('animationend', function() {
            this.style.animation = 'pulse 1.5s infinite, float 3s ease-in-out infinite';
        });
    });

    // Add pulse effect to feature cards
    const featureCards = document.querySelectorAll('.bg-white\\/5, .ring-white\\/10, div[class*="rounded-xl"]');
    featureCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px) scale(1.02)';
            this.style.boxShadow = '0 15px 40px rgba(0, 212, 255, 0.4)';
        });

        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '0 8px 32px rgba(0, 212, 255, 0.2)';
        });
    });

    // Add floating animation to hero logo
    const heroLogo = document.querySelector('img[alt*="QuietGo"]');
    if (heroLogo) {
        heroLogo.style.animation = 'float 4s ease-in-out infinite';
    }

    // Add attention-grabbing effects to CTA buttons
    const ctaButtons = document.querySelectorAll('a[href*="store"], a[class*="btn-primary"]');
    ctaButtons.forEach(cta => {
        // Add blinking effect
        setInterval(() => {
            cta.style.boxShadow = '0 0 20px rgba(255, 107, 53, 0.8)';
            setTimeout(() => {
                cta.style.boxShadow = '0 4px 15px rgba(255, 107, 53, 0.4)';
            }, 300);
        }, 2000);
    });

    // Scroll-triggered animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe all sections for scroll animations
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        section.style.opacity = '0';
        section.style.transform = 'translateY(50px)';
        section.style.transition = 'all 0.6s ease-out';
        observer.observe(section);
    });

    // Make sure hero section is always visible
    const heroSection = document.querySelector('section:first-of-type');
    if (heroSection) {
        heroSection.style.opacity = '1';
        heroSection.style.transform = 'translateY(0)';
    }

    // Add click tracking for conversion optimization
    document.querySelectorAll('a[href*="store"], a[data-open-gate]').forEach(link => {
        link.addEventListener('click', function() {
            console.log('CTA clicked:', this.href || this.textContent);
            // Add analytics tracking here if needed
        });
    });

    // Enhance navigation hover effects
    document.querySelectorAll('nav a, header a').forEach(navLink => {
        navLink.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.05)';
        });

        navLink.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
});

// Additional CSS animations via JavaScript
const additionalStyles = `
    @keyframes attention-pulse {
        0%, 100% { 
            box-shadow: 0 0 5px rgba(255, 107, 53, 0.5);
            transform: scale(1);
        }
        50% { 
            box-shadow: 0 0 25px rgba(255, 107, 53, 0.8);
            transform: scale(1.02);
        }
    }

    @keyframes slide-in-up {
        from {
            opacity: 0;
            transform: translateY(50px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-attention {
        animation: attention-pulse 2s infinite !important;
    }

    .animate-slide-in {
        animation: slide-in-up 0.6s ease-out forwards !important;
    }
`;

// Inject additional styles
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);
