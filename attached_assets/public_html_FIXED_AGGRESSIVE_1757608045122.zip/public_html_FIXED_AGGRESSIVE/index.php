<?php
declare(strict_types=1);

// Single entry: boot + dispatch
require __DIR__ . '/app/Routes/web.php';
