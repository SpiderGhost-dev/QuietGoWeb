<?php
declare(strict_types=1);

/**
 * App bootstrap:
 * - sessions
 * - env (.env one level above web root)
 * - security headers (CSP, etc.)
 * - global helpers (view(), config())
 */

if (session_status() === PHP_SESSION_NONE) { session_start(); }

// ---------- ENV loader (outside web root) ----------
function env_load_private(string $pathAbove): void {
  $envPath = rtrim($pathAbove, '/')."/.env";
  if (!isset($GLOBALS['__ENV_LOADED']) && is_readable($envPath)) {
    $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
      $line = trim($line);
      if ($line === '' || $line[0] === '#') continue;
      $pos = strpos($line, '=');
      if ($pos === false) continue;
      $k = trim(substr($line, 0, $pos));
      $v = trim(substr($line, $pos+1));
      if (!getenv($k)) putenv("$k=$v");
    }
    $GLOBALS['__ENV_LOADED'] = true;
  }
}
env_load_private(dirname(__DIR__, 2)); // one level above /public_html

// ---------- Security headers (defense-in-depth with .htaccess) ----------
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Permissions-Policy: camera=(), microphone=(), geolocation=()");
$__CSP_NONCE = base64_encode(random_bytes(16));
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; script-src 'self' 'nonce-$__CSP_NONCE' https://cdn.tailwindcss.com; font-src 'self' data:; connect-src 'self'");

// ---------- Global config ----------
require_once __DIR__ . '/../Config/app.php';

// ---------- Helpers ----------
/** Render a view with a layout. */
function view(string $page, array $data = []): void {
  extract($data, EXTR_OVERWRITE);
  $title = $title ?? APP_NAME . " — Plate to Pattern";
  $desc  = $desc  ?? "Free web demo. Full sync with mobile subscription.";
  $__CSP_NONCE = $GLOBALS['__CSP_NONCE'] ?? '';
  // Layout pieces:
  include __DIR__ . '/../Views/layouts/head.php';
  echo '<body class="bg-black text-neutral-200 antialiased selection:bg-teal-700/50 selection:text-white">';
  include __DIR__ . '/../Views/layouts/header.php';
  echo '<main id="content" class="min-h-[60vh]">';
  include __DIR__ . '/../Views/pages/' . $page . '.php';
  echo '</main>';
  include __DIR__ . '/../Views/layouts/footer.php';
  include __DIR__ . '/../Views/layouts/gate-modal.php';
  echo '<script nonce="'.htmlspecialchars($__CSP_NONCE, ENT_QUOTES).'" src="/public/js/site.js"></script>';
  echo '</body></html>';
}

/** Simple app config accessor (if you ever add arrays later). */
function config(string $key, mixed $default = null): mixed {
  return defined($key) ? constant($key) : $default;
}

// Demo flag default ON
if (!isset($_SESSION['demo'])) $_SESSION['demo'] = true;
