<?php declare(strict_types=1); ?>
<header class="sticky top-0 z-40 bg-black/80 backdrop-blur border-b border-white/10">
  <div class="max-w-7xl mx-auto px-5 py-4 flex items-center justify-between">
    <!-- LOGO IMAGE INSTEAD OF TEXT -->
    <a class="flex items-center gap-3" href="/" data-no-brand="1">
      <img src="/public/images/logo.png" alt="QuietGo Logo" class="header-logo" style="height: 40px; width: auto;" />
      <!-- Remove the tagline completely - it's clutter -->
    </a>
    <nav class="hidden md:flex items-center gap-8 text-white">
      <a class="hover:text-white/90" href="/">Home</a>
      <a class="hover:text-white/90" href="/faq">FAQ</a>
      <a class="hover:text-white/90" href="/support">Support</a>
      <a class="hover:text-white/90" href="/profile">Portal</a>
    </nav>
    <div class="flex items-center gap-3">
      <a href="#" data-open-gate class="btn btn-primary text-sm">Get the App</a>
    </div>
  </div>
</header>
