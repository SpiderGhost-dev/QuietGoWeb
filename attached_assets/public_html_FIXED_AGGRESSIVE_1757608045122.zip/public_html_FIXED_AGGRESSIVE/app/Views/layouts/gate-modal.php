<?php declare(strict_types=1); ?>
<div id="gate" class="fixed inset-0 hidden items-center justify-center bg-black/70 p-4">
  <div class="card rounded-2xl max-w-md w-full p-6">
    <div class="flex items-center gap-3">
      <img src="/public/images/app-icon.png" class="h-10 w-10 rounded-md" alt="app icon" />
      <div>
        <div class="font-semibold">Unlock sync with mobile subscription</div>
        <div class="text-white/60 text-sm">The web is a free demo. Full data sync unlocks with the iOS app.</div>
      </div>
    </div>
    <div class="mt-5 flex gap-3">
      <a href="<?= APP_STORE_URL ?>" class="px-4 py-2 rounded-md bg-teal-600 hover:bg-teal-500 text-white">Open App Store</a>
      <button data-close-gate class="px-4 py-2 rounded-md border border-white/10 hover:bg-white/5">Keep browsing</button>
    </div>
  </div>
</div>
