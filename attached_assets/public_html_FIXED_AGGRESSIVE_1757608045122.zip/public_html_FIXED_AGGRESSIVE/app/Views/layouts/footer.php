<?php declare(strict_types=1); $year = date('Y'); ?>
<footer class="border-t border-white/10 mt-16">
  <div class="max-w-6xl mx-auto px-4 py-10 grid sm:grid-cols-2 md:grid-cols-4 gap-8 text-sm">
    <div>
      <div class="flex items-center gap-2">
        <img src="/public/images/logo.png" class="h-6 w-6 rounded ring-1 ring-white/10" alt="logo" />
        <span class="text-lg">QuietGo</span>
      </div>
      <p class="mt-3 text-white/60">Educational patterns, privacy-first. Share insights, not photos.</p>
    </div>
    <div>
      <div class="font-medium text-white/80 mb-2">Product</div>
      <ul class="space-y-1">
        <li><a class="hover:text-white/90" href="/">Home</a></li>
        <li><a class="hover:text-white/90" href="/faq">FAQ</a></li>
        <li><a class="hover:text-white/90" href="/settings">Settings</a></li>
      </ul>
    </div>
    <div>
      <div class="font-medium text-white/80 mb-2">Company</div>
      <ul class="space-y-1">
        <li><a class="hover:text-white/90" href="/about">About</a></li>
        <li><a class="hover:text-white/90" href="/privacy">Privacy</a></li>
        <li><a class="hover:text-white/90" href="/terms">Terms</a></li>
      </ul>
    </div>
    <div>
      <div class="font-medium text-white/80 mb-2">Contact</div>
      <p class="text-white/70"><a class="underline" href="mailto:<?= SUPPORT_EMAIL ?>"><?= SUPPORT_EMAIL ?></a></p>
      <?php if (APP_STORE_URL !== 'https://apps.apple.com/' && APP_STORE_URL !== ''): ?>
  <a href="<?= APP_STORE_URL ?>" class="inline-flex items-center gap-2 mt-3 text-white/80 hover:text-white">
    <img src="/public/images/app-badge.png" class="h-6" alt="App Store" />
    <span>Get the app</span>
  </a>
<?php endif; ?>

    </div>
  </div>
  <div class="text-center text-xs text-white/50 py-4 border-t border-white/10">&copy; <?= $year ?> QuietGo. All rights reserved.</div>
</footer>
