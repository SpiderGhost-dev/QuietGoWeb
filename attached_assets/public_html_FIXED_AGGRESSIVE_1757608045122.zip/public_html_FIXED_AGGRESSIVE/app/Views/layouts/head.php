<?php
declare(strict_types=1);
/** @var string $title */
/** @var string $desc  */
$og = "/public/images/og-cover.png";
if (!is_file($_SERVER['DOCUMENT_ROOT'] . $og)) $og = "/public/images/logo.png";
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?= htmlspecialchars($title ?? APP_NAME) ?></title>
  <meta name="description" content="<?= htmlspecialchars($desc ?? 'QuietGo turns everyday logs into patterns you can use. Mobile capture, desktop clarity. Private by design.') ?>" />
  <meta property="og:title" content="<?= htmlspecialchars($title ?? APP_NAME) ?>" />
  <meta property="og:description" content="<?= htmlspecialchars($desc ?? 'Your gut talks. QuietGo translates.') ?>" />
  <meta property="og:image" content="<?= $og ?>" />
  <meta property="og:type" content="website" />
  <link rel="icon" href="/public/images/favicon.ico" sizes="any" />
  <link rel="shortcut icon" href="/public/images/favicon.ico" />
  <link rel="apple-touch-icon" href="/public/images/app-icon.png" />
  <meta name="theme-color" content="#000000" />

  <!-- Tailwind (needed for all the utility classes) -->
  <script src="https://cdn.tailwindcss.com"></script>

  <!-- Your existing site styles -->
  <link rel="stylesheet" href="/public/css/site.css" />

  <!-- Fonts for the new type system -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />

  <!-- QuietGo marketing helpers (text-90/80/60, buttons, etc.) -->
  <link rel="stylesheet" href="/public/css/quietgo.css" />

  <!-- AGGRESSIVE OVERRIDE CSS - LOADS LAST TO OVERRIDE EVERYTHING -->
  <link rel="stylesheet" href="/public/css/aggressive-override.css" />

  <style>
    :root{
      /* Base palette from config */
      --brand-cream: <?= BRAND_CREAM ?>;
      --brand-sage:  <?= BRAND_SAGE  ?>;
      --brand-rose:  <?= BRAND_ROSE  ?>;
      --brand-slate: <?= BRAND_SLATE ?>;
      --brand-steel: <?= BRAND_STEEL ?>;
      --brand-teal:  <?= BRAND_TEAL  ?>;

      /* Wordmark split colors (driven by config) */
      --qg-quiet: <?= BRAND_QUIET_WORD ?>;
      --qg-go:    <?= BRAND_GO_WORD    ?>;
    }

    /* Type families */
    body { font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif; background:#000; color:#fff; }
    h1, h2 { font-family: Fraunces, Georgia, serif; }

    /* Wordmark color targets (used by site.js brand enforcer) */
    .qg-quiet { color: var(--qg-quiet); }
    .qg-go    { color: var(--qg-go); }

    /* Small utilities your pages already expect */
    .card  { background: rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.12); border-radius: .75rem; }
    .muted { color: rgba(255,255,255,.72); }
    .lead  { color:#fff; font-size:clamp(1.125rem, 2.2vw, 1.375rem); line-height:1.5; }

    img:not([src]), img[src=""){ display:none; }
  </style>

  <!-- Enhanced Interactivity JavaScript -->
  <script src="/public/js/enhanced-interactions.js"></script>
</head>