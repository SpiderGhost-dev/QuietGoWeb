<?php /* Home (Public Marketing) — QuietGo */ ?>

<!-- COVER (above the fold) -->
<section class="relative">
  <div class="max-w-7xl mx-auto px-5 pt-16 pb-14 text-center">
    <!-- Big logo, clean edges -->
    <img src="/public/images/logo.png" alt="QuietGo" class="mx-auto block h-[26vh] sm:h-[28vh] md:h-[30vh] w-auto" />

    <!-- Title -->
    <h1 class="font-display mt-6 text-4xl sm:text-5xl md:text-6xl leading-tight tracking-tight text-90">
      Your gut talks. QuietGo translates.
    </h1>

    <!-- Subline -->
    <p class="font-ui mt-5 text-base sm:text-lg md:text-xl leading-relaxed text-80">
      Capture the moment. Connect the dots. Act with confidence.
    </p>

    <!-- CTAs -->
    <div class="mt-8 flex items-center justify-center gap-4 font-ui">
      <?php if (defined('APP_STORE_URL') && APP_STORE_URL !== '' && APP_STORE_URL !== 'https://apps.apple.com/'): ?>
        <a href="<?= APP_STORE_URL ?>" class="btn btn-primary text-base px-6">Get QuietGo for iOS</a>
      <?php endif; ?>
      <a href="#demo" class="btn btn-ghost text-base px-6">See 30-sec demo</a>
      <span class="text-xs sm:text-sm text-60">Android — coming soon · <a href="#waitlist" class="underline">Join waitlist</a></span>
    </div>

    <!-- Outcomes (3) -->
    <ul class="font-ui mt-6 text-left max-w-2xl mx-auto grid gap-2 text-80">
      <li>• Spot what actually helps — and what doesn’t</li>
      <li>• Stay consistent with light nudges</li>
      <li>• Review and export when you’re ready</li>
    </ul>

    <!-- Micro-trust -->
    <p class="font-ui mt-3 text-xs text-60">No ads. Export anytime.</p>
  </div>
</section>

<!-- AI EDGE -->
<section class="relative">
  <div class="max-w-6xl mx-auto px-5 py-12">
    <h2 class="font-display text-3xl sm:text-4xl text-90 mb-4">Let the app do the work.</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 font-ui">
      <div class="p-5 rounded-xl bg-white/5 ring-1 ring-white/10">
        <h3 class="text-white font-semibold mb-2">Auto-log</h3>
        <p class="text-80 text-sm">Meals (text or photo), bowel events, and notes captured and structured for you.</p>
      </div>
      <div class="p-5 rounded-xl bg-white/5 ring-1 ring-white/10">
        <h3 class="text-white font-semibold mb-2">Auto-organize</h3>
        <p class="text-80 text-sm">Clean timeline, smart categories, zero clutter.</p>
      </div>
      <div class="p-5 rounded-xl bg-white/5 ring-1 ring-white/10">
        <h3 class="text-white font-semibold mb-2">Auto-translate</h3>
        <p class="text-80 text-sm">Time, frequency, and features summarized in plain language you can act on.</p>
      </div>
    </div>
    <p class="font-ui mt-3 text-xs text-60">Guidance, not diagnosis. QuietGo offers non-medical suggestions based on your logs.</p>
  </div>
</section>

<!-- HOW IT WORKS -->
<section class="relative">
  <div class="max-w-6xl mx-auto px-5 py-12">
    <h2 class="font-display text-3xl sm:text-4xl text-90 mb-4">Phone = capture. Desktop = clarity.</h2>
    <ol class="font-ui grid grid-cols-1 md:grid-cols-5 gap-4 text-80">
      <li><span class="text-white/90 font-semibold">1) Log or snap.</span> One-tap time stamps; add details only if you want.</li>
      <li><span class="text-white/90 font-semibold">2) AI sorts it.</span> Entries land where they belong—no busywork.</li>
      <li><span class="text-white/90 font-semibold">3) Patterns emerge.</span> See what repeats and what changes.</li>
      <li><span class="text-white/90 font-semibold">4) Act on it.</span> Try simple suggestions; track what improves.</li>
      <li><span class="text-white/90 font-semibold">5) Go deeper on web.</span> Compare periods, organize, and export.</li>
    </ol>
  </div>
</section>

<!-- WHO IT'S FOR -->
<section class="relative">
  <div class="max-w-6xl mx-auto px-5 py-12">
    <h2 class="font-display text-3xl sm:text-4xl text-90 mb-6">Who it’s for</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 font-ui">
      <div class="p-5 rounded-xl bg-white/5 ring-1 ring-white/10">
        <h3 class="text-white font-semibold mb-1">Everyday wellness</h3>
        <p class="text-80 text-sm">Understand how routine affects how you feel.</p>
      </div>
      <div class="p-5 rounded-xl bg-white/5 ring-1 ring-white/10">
        <h3 class="text-white font-semibold mb-1">Athletes & active</h3>
        <p class="text-80 text-sm">Align training, fuel, and recovery.</p>
      </div>
      <div class="p-5 rounded-xl bg-white/5 ring-1 ring-white/10">
        <h3 class="text-white font-semibold mb-1">Cycle-aware tracking</h3>
        <p class="text-80 text-sm">Plan around predictable shifts.</p>
      </div>
      <div class="p-5 rounded-xl bg-white/5 ring-1 ring-white/10">
        <h3 class="text-white font-semibold mb-1">Busy & high-stress</h3>
        <p class="text-80 text-sm">Separate stress effects from diet effects.</p>
      </div>
      <div class="p-5 rounded-xl bg-white/5 ring-1 ring-white/10">
        <h3 class="text-white font-semibold mb-1">Travel & shift work</h3>
        <p class="text-80 text-sm">Keep rhythm when your schedule doesn’t.</p>
      </div>
      <div class="p-5 rounded-xl bg-white/5 ring-1 ring-white/10">
        <h3 class="text-white font-semibold mb-1">Food experiments</h3>
        <p class="text-80 text-sm">Test what supports you—without the noise.</p>
      </div>
    </div>
  </div>
</section>

<!-- PROOF / DEMO -->
<section id="demo" class="relative">
  <div class="max-w-6xl mx-auto px-5 py-12">
    <h2 class="font-display text-3xl sm:text-4xl text-90 mb-4">What clarity looks like</h2>
    <div class="rounded-xl overflow-hidden bg-white/5 ring-1 ring-white/10">
      <img src="/public/images/demo-dashboard.png" alt="QuietGo demo" class="w-full h-auto block" />
    </div>
    <p class="font-ui mt-3 text-center text-xs text-60">Screens simulated for privacy.</p>
  </div>
</section>

<!-- SHARING -->
<section class="relative">
  <div class="max-w-6xl mx-auto px-5 py-12">
    <h2 class="font-display text-3xl sm:text-4xl text-90 mb-4">Sharing — on your terms</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 font-ui">
      <div class="p-5 rounded-xl bg-white/5 ring-1 ring-white/10">
        <h3 class="text-white font-semibold mb-2">QuickShare</h3>
        <p class="text-80 text-sm">One tap status-only: “Done today.” No details.</p>
      </div>
      <div class="p-5 rounded-xl bg-white/5 ring-1 ring-white/10">
        <h3 class="text-white font-semibold mb-2">Checklist share</h3>
        <p class="text-80 text-sm">Pick exactly what to include. Photos off by default; “type” in plain words only.</p>
      </div>
      <div class="p-5 rounded-xl bg-white/5 ring-1 ring-white/10">
        <h3 class="text-white font-semibold mb-2">QuietGo Digest (opt-in)</h3>
        <p class="text-80 text-sm">Weekly summaries to people you choose. Pause, snooze, or stop anytime.</p>
      </div>
    </div>
  </div>
</section>

<!-- PRICING -->
<section class="relative">
  <div class="max-w-5xl mx-auto px-5 py-14 text-center">
    <h2 class="font-display text-3xl sm:text-4xl text-90 mb-4">Start free. Upgrade when you want clarity.</h2>
    <p class="font-ui text-80 text-sm sm:text-base">
      Free: explore on the web; light logging.<br/>
      <span class="text-white font-semibold">Pro — $4.99/mo or $39.99/yr</span>: unlimited history, analytics, exports, priority support.<br/>
      <span class="text-white font-semibold">Meal Photo AI Add-On</span>: automatic macro extraction from meal photos (optional).
    </p>
    <div class="mt-6 font-ui">
      <?php if (defined('APP_STORE_URL') && APP_STORE_URL !== '' && APP_STORE_URL !== 'https://apps.apple.com/'): ?>
        <a href="<?= APP_STORE_URL ?>" class="btn btn-primary text-base px-6">Get QuietGo for iOS</a>
      <?php else: ?>
        <a href="#demo" class="btn btn-primary text-base px-6">See the demo</a>
      <?php endif; ?>
      <p class="mt-3 text-xs text-60">Android — coming soon · <a href="#waitlist" class="underline">Join waitlist</a></p>
    </div>
  </div>
</section>

<!-- FINAL CTA -->
<section class="relative">
  <div class="max-w-5xl mx-auto px-5 pb-20 text-center">
    <h2 class="font-display text-3xl sm:text-4xl text-90 mb-3">Capture on your phone. Understand on your desktop.</h2>
    <p class="font-ui text-80 text-sm sm:text-base">The discreet way to notice what actually helps — and what doesn’t.</p>
    <div class="mt-6 font-ui">
      <?php if (defined('APP_STORE_URL') && APP_STORE_URL !== '' && APP_STORE_URL !== 'https://apps.apple.com/'): ?>
        <a href="<?= APP_STORE_URL ?>" class="btn btn-primary text-base px-6">Get QuietGo for iOS</a>
      <?php else: ?>
        <a href="#demo" class="btn btn-ghost text-base px-6">See 30-sec demo</a>
      <?php endif; ?>
    </div>
  </div>
</section>
