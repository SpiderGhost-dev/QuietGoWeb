<section class="max-w-4xl mx-auto px-4 py-14 space-y-6">
  <h1 class="text-3xl font-semibold">Terms of Service</h1>
  <p class="text-white/70">QuietGo is educational software and does not provide medical advice. Subscriptions are handled via Apple; refunds follow App Store policies.</p>
  <ul class="list-disc pl-5 text-white/70 space-y-2">
    <li>Acceptable use: no unlawful or harmful content.</li>
    <li>Exports: PDF/CSV available to subscribers.</li>
    <li>Uptime &amp; liability: provided “as is”.</li>
    <li>Jurisdiction &amp; contact: <a class="underline" href="mailto:<?= SUPPORT_EMAIL ?>"><?= SUPPORT_EMAIL ?></a></li>
  </ul>
</section>
