<section class="max-w-4xl mx-auto px-4 py-14 space-y-6">
  <h1 class="text-3xl font-semibold">FAQ</h1>
  <details class="card rounded-xl p-4" open>
    <summary class="font-medium cursor-pointer">Is this medical?</summary>
    <p class="text-white/70 mt-2">Nope. QuietGo is educational. For medical advice, talk to your clinician.</p>
  </details>
  <details class="card rounded-xl p-4">
    <summary class="font-medium cursor-pointer">Do you store my photos?</summary>
    <p class="text-white/70 mt-2">Images are analyzed then auto-deleted by default. You control sharing and exports.</p>
  </details>
  <details class="card rounded-xl p-4">
    <summary class="font-medium cursor-pointer">How accurate is the AI?</summary>
    <p class="text-white/70 mt-2">It’s an estimate to help you notice patterns. You can edit or override at any time.</p>
  </details>
  <details class="card rounded-xl p-4">
    <summary class="font-medium cursor-pointer">How do I export?</summary>
    <p class="text-white/70 mt-2">Subscribers can export PDF/CSV from the dashboard. The web demo is read-only.</p>
  </details>
  <details class="card rounded-xl p-4">
    <summary class="font-medium cursor-pointer">What’s the Meal Photo AI add-on?</summary>
    <p class="text-white/70 mt-2">Auto-log foods, portions, and macros from a plate photo. Optional add-on.</p>
  </details>
</section>
