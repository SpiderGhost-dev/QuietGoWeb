<section class="max-w-5xl mx-auto px-5 py-14 space-y-10">
  <header class="text-center">
    <h1 class="text-4xl font-bold text-white"><span class="qg">QuietGo</span> — Plate to Pattern</h1>
    <p class="lead mt-4">Discreet, educational, privacy-first. The mobile app captures; the web reveals.</p>
  </header>

  <div class="grid md:grid-cols-3 gap-6">
    <div class="card rounded-2xl p-6">
      <div class="text-xl font-semibold text-white">Privacy by default</div>
      <p class="muted mt-2">Images are analyzed then auto-deleted (default ON). You control sharing.</p>
    </div>
    <div class="card rounded-2xl p-6">
      <div class="text-xl font-semibold text-white">Patterns over noise</div>
      <p class="muted mt-2">Correlations and rhythms stated in plain English you can act on.</p>
    </div>
    <div class="card rounded-2xl p-6">
      <div class="text-xl font-semibold text-white">Your data, your choice</div>
      <p class="muted mt-2">Export as PDF/CSV. Share insights, not photos.</p>
    </div>
  </div>

  <div class="card rounded-2xl p-6">
    <h2 class="text-2xl font-semibold text-white mb-3">How it works</h2>
    <ol class="list-decimal pl-6 space-y-2 muted">
      <li>Use the iOS app to capture discreetly (meals, stool, notes).</li>
      <li>Data sync unlocks with your mobile subscription.</li>
      <li>The web dashboard shows patterns and generates Rhythm Reports.</li>
    </ol>
  </div>
</section>
