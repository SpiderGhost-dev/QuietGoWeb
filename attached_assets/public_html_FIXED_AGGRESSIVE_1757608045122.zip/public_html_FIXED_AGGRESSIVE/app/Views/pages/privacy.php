<section class="max-w-4xl mx-auto px-4 py-14 space-y-6">
  <h1 class="text-3xl font-semibold">Privacy Policy</h1>
  <p class="text-white/70">Plain English summary. This web demo collects minimal analytics. Images in the mobile app are analyzed and then auto-deleted by default.</p>
  <h2 class="text-xl font-semibold mt-6">Data we collect</h2>
  <ul class="list-disc pl-5 text-white/70 space-y-2">
    <li>Account email and basic settings.</li>
    <li>Structured logs for troubleshooting (no raw photos).</li>
  </ul>
  <h2 class="text-xl font-semibold mt-6">Your controls</h2>
  <ul class="list-disc pl-5 text-white/70 space-y-2">
    <li>Sharing controls with link expiration.</li>
    <li>Export your data (PDF/CSV) as a subscriber.</li>
    <li>Request deletion via <a class="underline" href="mailto:<?= SUPPORT_EMAIL ?>"><?= SUPPORT_EMAIL ?></a>.</li>
  </ul>
  <p class="text-white/60 mt-6 text-sm">Educational use only. Not medical advice.</p>
</section>
