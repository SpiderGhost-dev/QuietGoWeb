<section class="max-w-3xl mx-auto px-4 py-14 space-y-6">
  <h1 class="text-3xl font-semibold">Settings</h1>
  <div class="card rounded-xl p-5 space-y-4 opacity-80">
    <label class="flex items-center gap-3">
      <input type="checkbox" checked disabled class="accent-teal-600">
      <span>Auto-delete images after analysis (default ON)</span>
    </label>
    <label class="flex items-center gap-3">
      <input type="checkbox" disabled class="accent-teal-600">
      <span>Share insights with a link (manage recipients)</span>
    </label>
    <label class="flex items-center gap-3">
      <input type="checkbox" disabled class="accent-teal-600">
      <span>Enable reminders</span>
    </label>
    <button data-open-gate class="px-4 py-2 rounded-md bg-white/5 border border-white/10">Save changes</button>
  </div>
</section>
