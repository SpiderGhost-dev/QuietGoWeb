<section class="max-w-3xl mx-auto px-5 py-14">
  <h1 class="text-4xl font-bold text-white">Support</h1>
  <p class="muted mt-3">Email us at <a class="underline" href="mailto:<?= SUPPORT_EMAIL ?>"><?= SUPPORT_EMAIL ?></a> or use the form.</p>

  <form class="card rounded-2xl p-6 mt-8 grid gap-4" method="post" action="/contact" novalidate>
    <input type="hidden" name="website" value="" /> <!-- honeypot -->
    <label class="grid gap-2">
      <span class="text-white">Email</span>
      <input name="email" type="email" required class="bg-black border border-white/15 rounded-lg px-3 py-2 text-white" placeholder="you@example.com" />
    </label>
    <label class="grid gap-2">
      <span class="text-white">Subject</span>
      <input name="subject" required class="bg-black border border-white/15 rounded-lg px-3 py-2 text-white" placeholder="How can we help?" />
    </label>
    <label class="grid gap-2">
      <span class="text-white">Message</span>
      <textarea name="message" rows="6" required class="bg-black border border-white/15 rounded-lg px-3 py-2 text-white" placeholder="Share details so we can help fast."></textarea>
    </label>
    <button class="btn btn-primary w-fit">Send</button>
  </form>
</section>
