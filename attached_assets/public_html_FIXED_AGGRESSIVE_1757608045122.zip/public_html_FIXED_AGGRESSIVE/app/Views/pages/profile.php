<?php $plan = $_SESSION['demo'] ? "Demo" : "Pro"; ?>
<section class="max-w-3xl mx-auto px-4 py-14 space-y-6">
  <h1 class="text-3xl font-semibold">Profile</h1>
  <div class="card rounded-xl p-5">
    <div class="grid sm:grid-cols-2 gap-4">
      <div><div class="text-white/60 text-sm">Plan</div><div class="text-lg"><?= $plan ?></div></div>
      <div><div class="text-white/60 text-sm">Add-On</div><div class="text-lg">Not enabled</div></div>
      <div><div class="text-white/60 text-sm">Manage</div><a class="underline" href="<?= APP_STORE_URL ?>">App Store</a></div>
      <div><div class="text-white/60 text-sm">Email</div><div class="text-lg"><?= SUPPORT_EMAIL ?></div></div>
    </div>
    <div class="mt-4">
      <button data-open-gate class="px-4 py-2 rounded-md bg-teal-600 hover:bg-teal-500 text-white">Upgrade</button>
    </div>
  </div>
</section>
