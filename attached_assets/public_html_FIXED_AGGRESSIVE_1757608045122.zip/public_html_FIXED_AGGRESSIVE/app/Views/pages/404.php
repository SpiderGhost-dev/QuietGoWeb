<section class="max-w-3xl mx-auto px-4 py-20 text-center">
  <h1 class="text-4xl font-semibold">Page not found</h1>
  <p class="text-white/70 mt-3">That path doesn’t exist. Head back to the demo.</p>
  <a href="/" class="inline-block mt-6 px-5 py-2.5 rounded-md bg-teal-600 hover:bg-teal-500 text-white">Go home</a>
</section>
