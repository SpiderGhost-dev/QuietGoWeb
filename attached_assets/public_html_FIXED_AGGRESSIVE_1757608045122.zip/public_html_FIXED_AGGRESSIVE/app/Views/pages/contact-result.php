<section class="max-w-3xl mx-auto px-4 py-14">
  <h1 class="text-3xl font-semibold">Support</h1>
  <p class="mt-4 <?= !empty($ok) ? 'text-teal-400' : 'text-red-400' ?>"><?= htmlspecialchars($msg ?? "Error") ?></p>
  <p class="text-white/70 mt-2">Email us directly: <a class="underline" href="mailto:<?= SUPPORT_EMAIL ?>"><?= SUPPORT_EMAIL ?></a></p>
</section>
