<?php
declare(strict_types=1);
use App\Http\Controllers\PageController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\AnalyticsController;

require_once __DIR__ . '/../Bootstrap/init.php';
require_once __DIR__ . '/../Http/Controllers/PageController.php';
require_once __DIR__ . '/../Http/Controllers/ContactController.php';
require_once __DIR__ . '/../Http/Controllers/AnalyticsController.php';

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$path = rtrim($path, '/'); if ($path === '') $path = '/';

$pages = new PageController();
$contact = new ContactController();
$analytics = new AnalyticsController();

$routes = [
  '/' => fn() => $pages->home(),
  '/about' => fn() => $pages->about(),
  '/privacy' => fn() => $pages->privacy(),
  '/terms' => fn() => $pages->terms(),
  '/faq' => fn() => $pages->faq(),
  '/support' => fn() => $pages->support(),
  '/settings' => fn() => $pages->settings(),
  '/profile' => fn() => $pages->profile(),
  '/contact' => fn() => $contact->send(),
  '/beacon'  => fn() => $analytics->beacon(),
];

// Dispatch or 404
if (isset($routes[$path])) {
  $routes[$path]();
} else {
  http_response_code(404);
  view('404', ['title' => '404 — QuietGo']);
}
