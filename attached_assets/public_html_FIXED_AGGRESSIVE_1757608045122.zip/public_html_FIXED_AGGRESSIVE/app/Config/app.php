<?php
declare(strict_types=1);
const APP_NAME='QuietGo';
const PRO_ANNUAL='39.99'; const PRO_MONTHLY='4.99';
const ADDON_ANNUAL='19.99'; const ADDON_MONTHLY='2.99';
const APP_STORE_URL='https://apps.apple.com/';
const SUPPORT_EMAIL='Support@QuietGo.app';

/** Base palette (already present, keep as-is) */
const BRAND_CREAM='#F7EDD4';
const BRAND_SAGE ='#6C985F';
const BRAND_ROSE ='#D4A799';
const BRAND_SLATE='#6A7BA2';
const BRAND_STEEL='#4682B4';
const BRAND_TEAL ='#3C9D9B';

/** NEW — split wordmark colors (edit these 2 if your logo uses different ones) */
const BRAND_QUIET_WORD = BRAND_CREAM; // Quiet = ivory
const BRAND_GO_WORD    = BRAND_ROSE;  // Go = off-pink

