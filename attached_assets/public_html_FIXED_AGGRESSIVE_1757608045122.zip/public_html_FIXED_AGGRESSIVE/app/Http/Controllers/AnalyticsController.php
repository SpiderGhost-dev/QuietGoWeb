<?php
declare(strict_types=1);

namespace App\Http\Controllers;

final class AnalyticsController {
  public function beacon(): void {
    // Only accept POST with JSON; no PII, cap size.
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
      http_response_code(405); header('Allow: POST'); exit;
    }

    $raw = file_get_contents('php://input') ?: '';
    if (strlen($raw) > 2048) { // 2KB cap
      http_response_code(413); exit;
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) { $data = []; }
    // Whitelist fields, strip PII
    $record = [
      't'  => (int)($data['t'] ?? time()*1000),
      'p'  => substr((string)($data['p'] ?? ($_SERVER['REQUEST_URI'] ?? '/')), 0, 256),
      'ua' => substr((string)($data['ua'] ?? ''), 0, 128),
      'ip' => substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64),
    ];

    // Write JSONL into storage/logs/app.log
    $logDir = __DIR__ . '/../../../storage/logs';
    $log = $logDir . '/app.log';
    if (!is_dir($logDir)) { @mkdir($logDir, 0700, true); }
    @file_put_contents($log, json_encode($record, JSON_UNESCAPED_SLASHES) . PHP_EOL, FILE_APPEND | LOCK_EX);

    header('Content-Type: application/json'); echo '{"ok":true}';
  }
}
