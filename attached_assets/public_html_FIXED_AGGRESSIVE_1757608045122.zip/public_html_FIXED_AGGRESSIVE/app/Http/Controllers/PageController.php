<?php
declare(strict_types=1);

namespace App\Http\Controllers;

final class PageController {
  public function home(): void {
    view('home', [
      'title' => 'QuietGo — Free Web Demo',
      'desc'  => 'See patterns that matter. Web demo now; sync with mobile subscription.'
    ]);
  }
  public function about(): void  { view('about',  ['title' => 'About — QuietGo']); }
  public function privacy(): void{ view('privacy',['title' => 'Privacy — QuietGo']); }
  public function terms(): void  { view('terms',  ['title' => 'Terms — QuietGo']); }
  public function faq(): void    { view('faq',    ['title' => 'FAQ — QuietGo']); }
  public function settings(): void { view('settings', ['title'=>'Settings — QuietGo']); }
  public function profile(): void  { view('profile',  ['title'=>'Profile — QuietGo']); }
  public function support(): void { view('support', ['title'=>'Support — QuietGo']); }

}
