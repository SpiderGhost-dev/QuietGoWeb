<?php
declare(strict_types=1);

namespace App\Http\Controllers;

final class ContactController {
  public function send(): void {
    $ok = false; $msg = "Something went wrong.";
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
      $email   = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
      $subject = trim((string)($_POST['subject'] ?? ''));
      $message = trim((string)($_POST['message'] ?? ''));
      $honeypot= trim((string)($_POST['website'] ?? ''));
      $ip      = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

      if (!$email || strlen($subject)<3 || strlen($subject)>120 || strlen($message)<5 || strlen($message)>2000) {
        $msg = "Please check your inputs and try again.";
      } elseif ($honeypot !== '') {
        $msg = "Please try again.";
      } else {
        $now  = time();
        $last = $_SESSION['last_contact_time'] ?? 0;
        if ($now - $last < 60) {
          $msg = "Please wait a minute before sending another message.";
        } else {
          $_SESSION['last_contact_time'] = $now;
          $headers = "From: <$email>\r\nReply-To: $email\r\nContent-Type: text/plain; charset=UTF-8\r\n";
          $body = "From: $email\nIP: $ip\n\nSubject: $subject\n\n$message\n";
          $ok = @mail(SUPPORT_EMAIL, "[QuietGo] $subject", $body, $headers);
          $msg = $ok ? "Thanks! We'll get back to you shortly." : "We couldn't send your message right now.";
        }
      }
    }
    view('contact-result', ['ok' => $ok, 'msg' => $msg, 'title' => 'Support — QuietGo']);
  }
}
