#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-public_html}"

echo "== Checking .htaccess at web root =="
if grep -q "RewriteRule \^ index\.php" "$ROOT/.htaccess"; then
  echo "OK: rewrite to index.php"
else
  echo "WARN: no rewrite rule"
fi

echo "== Checking security headers in .htaccess =="
if grep -Eq "X-Content-Type-Options|X-Frame-Options|Referrer-Policy|Strict-Transport-Security" "$ROOT/.htaccess"; then
  echo "OK: headers present"
else
  echo "WARN: headers missing"
fi

echo "== Checking storage protections =="
if [ -f "$ROOT/storage/.htaccess" ]; then
  if grep -Eq "Require all denied|Deny from all" "$ROOT/storage/.htaccess"; then
    echo "OK: storage denied"
  else
    echo "WARN: storage not fully denied"
  fi
else
  echo "WARN: storage/.htaccess missing"
fi

echo "== Checking public asset paths =="
for p in "$ROOT/public/images" "$ROOT/public/css" "$ROOT/public/js"; do
  if [ -d "$p" ]; then
    echo "OK: $p exists"
  else
    echo "WARN: $p missing"
  fi
done
