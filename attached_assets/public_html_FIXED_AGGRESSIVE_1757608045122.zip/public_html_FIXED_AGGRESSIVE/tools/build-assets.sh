#!/usr/bin/env bash
set -euo pipefail

echo "== Building assets for QuietGo =="

# CSS minify placeholder
if [ -f public/css/site.css ]; then
  echo "Would minify: public/css/site.css -> public/css/site.min.css"
fi

# JS minify placeholder
if [ -f public/js/site.js ]; then
  echo "Would minify: public/js/site.js -> public/js/site.min.js"
fi

# Image optimization placeholder
if [ -d public/images ]; then
  echo "Would optimize images in public/images/"
fi

echo "== Done (no real work yet) =="
