# Tools

Utility scripts for QuietGo.

- `check-security.sh` — verify rewrites, headers, and storage lockdown.
- `build-assets.sh` — placeholder for CSS/JS minify and image optimization.

## Usage
Run from project root:
