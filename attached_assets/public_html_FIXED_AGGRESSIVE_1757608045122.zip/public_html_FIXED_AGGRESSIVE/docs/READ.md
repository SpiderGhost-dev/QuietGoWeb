# QuietGo Web

Organized PHP site for shared hosting (hPanel-ready).

## Structure
- `/public` — static assets (images, css, js)
- `/app` — app code (Bootstrap, Config, Routes, Controllers, Views)
- `/storage` — non-public (logs, cache, exports; blocked by .htaccess)
- `/docs` — human-facing documentation
- `/tools` — utility scripts (security, build, etc.)

## Key features
- Free **web demo**. Full sync via **mobile subscription**.
- Add-on: **Meal Photo AI**.
- Privacy-first: images auto-deleted by default.
- Brand locked: all “QuietGo” mentions use the `.brand-quietgo` utility (logo’s font/color).

## Getting started
1. Upload project to hPanel `public_html`.
2. Enable hidden files in File Manager (for `.htaccess`).
3. Place secrets in `.env` one level above web root.
4. Confirm `/storage/.htaccess` is active (denies access).
5. Test routes: `/`, `/about`, `/faq`, `/support`, `/contact`.
