# Deploy (hPanel)

1. Upload files to your site root.
2. Verify `.htaccess`:
   - Pretty URLs rewrite to `index.php`
   - Security headers present
3. Secrets:
   - Place `.env` **one level above** web root:
     ```
     QUIETGO_SMTP_HOST=smtp.example.com
     QUIETGO_SMTP_USER=apikey
     QUIETGO_SMTP_PASS=secret
     ```
4. Storage:
   - `storage/.htaccess` blocks web access
   - Folders: logs, cache, exports
5. Test routes:
   - `/`, `/about`, `/support`, POST `/contact`
   - `/beacon` should return `{"ok":true}` on POST
   - 
   
=======================================================

# Deploy Guide — QuietGo Web

## hPanel upload
1. Upload and extract the project archive into your site root.
2. Verify `.htaccess` is present in:
   - `public_html/.htaccess` (rewrites to index.php, security headers)
   - `public_html/storage/.htaccess` (deny all)

## Environment
- Place `.env` one level above `public_html`.
- Example `.env`:

=======================================================

QUIETGO_SMTP_HOST=smtp.example.com
QUIETGO_SMTP_USER=apikey
QUIETGO_SMTP_PASS=secret


## Storage
- `/storage/logs`: logs (no PII; rotate weekly).
- `/storage/cache`: scratch.
- `/storage/exports`: temp PDF/CSV (purge daily).

## Testing
- `/` — home demo loads.
- `/contact` — form submits (rate-limited).
- `/beacon` — POST should return `{"ok":true}`.

## Security
- HTTPS enforced (HSTS in `.htaccess`).
- CSP and security headers active.
- Directories blocked by default.
