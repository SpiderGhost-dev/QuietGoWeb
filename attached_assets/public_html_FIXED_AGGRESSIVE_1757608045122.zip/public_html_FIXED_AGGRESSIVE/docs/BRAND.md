# QuietGo Brand Guide (Web)

## Name
- Always **QuietGo** (capital Q, capital G).
- Never “Quietgo” or “quietGo.”

## Styling
- Utility class: `.brand-quietgo`.
- Font: logo font (fallback: serif).
- Color: Rose `#D4A799`.

## Palette
- Cream `#F5F5DC`
- Sage  `#6C985F`
- Rose  `#D4A799`
- Slate `#6A7BA2`
- Steel `#4682B4`
- Teal  `#3C9D9B`
- Background: black site-wide.

## Usage rules
- All mentions of “QuietGo” in headers, footers, titles, and viable body text must use `.brand-quietgo`.
- Never alter case, color, or font.
- Do not place logo/text on busy backgrounds.

## Tone
- Direct, witty, no fluff.
- Avoid medical claims. Educational only.
- Taglines:
  - “Free web demo. Full sync with mobile subscription.”
  - “Stop guessing. Start seeing what drives your gut.”
  - “Share insights, not photos.”
