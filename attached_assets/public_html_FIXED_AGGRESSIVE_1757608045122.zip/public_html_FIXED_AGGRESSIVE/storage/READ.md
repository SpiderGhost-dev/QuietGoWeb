# /storage (non-public)

This directory holds runtime files that **must not** be web-accessible.

## Folders
- `/logs/` — application and security logs. **No PII** (no message bodies). Keep only timestamps, route, and coarse user agent if needed.
- `/cache/` — simple file cache scratch.
- `/exports/` — temporary generated files (PDF/CSV) before download. Clean up after delivery.

## Retention
- Logs: rotate weekly, keep 4 weeks.
- Exports: delete after 24h.
- Cache: purge on deploy.

## Notes
- Web access is blocked via `.htaccess`.
- Ensure filesystem perms keep this private (see below).

## Permissions (recommended)
