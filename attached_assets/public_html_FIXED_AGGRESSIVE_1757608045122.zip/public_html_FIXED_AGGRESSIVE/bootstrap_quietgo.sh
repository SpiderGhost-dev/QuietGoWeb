#!/usr/bin/env bash
set -euo pipefail

ROOT="public_html"
mkdir -p "$ROOT"/{inc,pages,assets,js}

# ---------- .htaccess ----------
cat > "$ROOT/.htaccess" <<'HT'
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^ index.php [QSA,L]
Options -Indexes
<FilesMatch "^\.">
  Require all denied
</FilesMatch>
<FilesMatch "\.(bak|old|orig|save|swp)$">
  Require all denied
</FilesMatch>
<IfModule mod_headers.c>
  Header always set X-Content-Type-Options "nosniff"
  Header always set X-Frame-Options "SAMEORIGIN"
  Header always set Referrer-Policy "strict-origin-when-cross-origin"
  Header always set Permissions-Policy "camera=(), microphone=(), geolocation=()"
  Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains" env=HTTPS
</IfModule>
HT

# ---------- config.php ----------
cat > "$ROOT/config.php" <<'PHP'
<?php
declare(strict_types=1);
if (session_status() === PHP_SESSION_NONE) { session_start(); }

const APP_NAME='QuietGo';
const PRO_ANNUAL='39.99'; const PRO_MONTHLY='4.99';
const ADDON_ANNUAL='19.99'; const ADDON_MONTHLY='2.99';
const APP_STORE_URL='https://apps.apple.com/'; // replace later
const SUPPORT_EMAIL='Support@QuietGo.app';      // display value

function env_load_private(string $pathAbove): void {
  $envPath = rtrim($pathAbove, '/')."/.env";
  if (!isset($GLOBALS['__ENV_LOADED']) && is_readable($envPath)) {
    $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
      if (strpos(trim($line), '#') === 0 || !str_contains($line, '=')) continue;
      [$k, $v] = array_map('trim', explode('=', $line, 2));
      if (!getenv($k)) putenv("$k=$v");
    }
    $GLOBALS['__ENV_LOADED'] = true;
  }
}
env_load_private(dirname(__DIR__));

if (!isset($_SESSION['demo'])) { $_SESSION['demo'] = true; }

$SITE = [
  'brand' => APP_NAME,
  'supportEmail' => SUPPORT_EMAIL,
  'appStoreUrl' => APP_STORE_URL,
  'pricing' => [
    'pro' => ['monthly' => PRO_MONTHLY, 'annual' => PRO_ANNUAL],
    'addon' => ['monthly' => ADDON_MONTHLY, 'annual' => ADDON_ANNUAL]
  ]
];
PHP

# ---------- routes.php ----------
cat > "$ROOT/routes.php" <<'PHP'
<?php
declare(strict_types=1);
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$path = rtrim($path, '/'); if ($path==='') $path='/';
$map = [
  '/' => 'home.php',
  '/about' => 'about.php',
  '/privacy' => 'privacy.php',
  '/terms' => 'terms.php',
  '/support' => 'support.php',
  '/faq' => 'faq.php',
  '/settings' => 'settings.php',
  '/profile' => 'profile.php',
];
$page = $map[$path] ?? 'home.php';
require __DIR__ . "/pages/$page";
PHP

# ---------- index.php ----------
cat > "$ROOT/index.php" <<'PHP'
<?php
declare(strict_types=1);
require __DIR__ . '/config.php';
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: strict-origin-when-cross-origin");
header("Permissions-Policy: camera=(), microphone=(), geolocation=()");
$nonce = base64_encode(random_bytes(16));
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; script-src 'self' 'nonce-$nonce' https://cdn.tailwindcss.com; font-src 'self' data:; connect-src 'self'");
?>
<?php include __DIR__ . '/inc/head.php'; ?>
<body class="bg-black text-neutral-200 antialiased selection:bg-teal-700/50 selection:text-white">
  <?php include __DIR__ . '/inc/header.php'; ?>
  <main id="content" class="min-h-[60vh]">
    <?php require __DIR__ . '/routes.php'; ?>
  </main>
  <?php include __DIR__ . '/inc/footer.php'; ?>
  <?php include __DIR__ . '/inc/gate-modal.php'; ?>
  <script nonce="<?= $nonce ?>" src="/js/site.js"></script>
</body>
</html>
PHP

# ---------- inc/head.php ----------
cat > "$ROOT/inc/head.php" <<'PHP'
<?php
declare(strict_types=1);
$title = $title ?? APP_NAME . " — Plate to Pattern";
$desc  = $desc ?? "Free web demo. Full sync with mobile subscription. See the patterns that drive your gut.";
$og    = "/assets/og-cover.png";
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?= htmlspecialchars($title) ?></title>
  <meta name="description" content="<?= htmlspecialchars($desc) ?>" />
  <meta property="og:title" content="<?= htmlspecialchars($title) ?>" />
  <meta property="og:description" content="<?= htmlspecialchars($desc) ?>" />
  <meta property="og:image" content="<?= $og ?>" />
  <meta property="og:type" content="website" />
  <link rel="icon" href="/assets/favicon.ico" />
  <script>window.__SITE__ = <?= json_encode($SITE) ?>;</script>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="/assets/site.css" />
  <style>
    :root {
      --brand-cream:#F5F5DC;
      --brand-sage:#6C985F;
      --brand-rose:#D4A799;
      --brand-slate:#6A7BA2;
      --brand-steel:#4682B4;
      --brand-teal:#3C9D9B;
      --brand-font: 'LogoFont', ui-serif, Georgia, serif;
    }
    .brand-quietgo { color: var(--brand-rose); font-family: var(--brand-font); letter-spacing: .3px; }
    .card { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); }
    .card:hover { border-color: rgba(255,255,255,0.16); }
  </style>
</head>
PHP

# ---------- inc/header.php ----------
cat > "$ROOT/inc/header.php" <<'PHP'
<?php declare(strict_types=1); ?>
<header class="sticky top-0 z-40 bg-black/80 backdrop-blur border-b border-white/10">
  <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
    <a class="flex items-center gap-3" href="/">
      <img src="/assets/logo.png" alt="QuietGo logo" class="h-8 w-8 rounded-md ring-1 ring-white/10" />
      <span class="text-xl brand-quietgo">QuietGo</span>
      <span class="text-xs text-white/50 ml-2 hidden sm:inline">Plate to Pattern</span>
    </a>
    <nav class="hidden md:flex items-center gap-6">
      <a class="hover:text-white/90" href="/about">About</a>
      <a class="hover:text-white/90" href="/faq">FAQ</a>
      <a class="hover:text-white/90" href="/privacy">Privacy</a>
      <a class="hover:text-white/90" href="/terms">Terms</a>
      <a class="hover:text-white/90" href="/support">Support</a>
    </nav>
    <div class="flex items-center gap-3">
      <a href="/profile" class="px-3 py-1.5 rounded-md text-sm bg-white/5 border border-white/10 hover:bg-white/10">Profile</a>
      <a href="#" data-open-gate class="px-3 py-1.5 rounded-md text-sm bg-teal-600 hover:bg-teal-500 text-white">Sync</a>
    </div>
  </div>
</header>
PHP

# ---------- inc/footer.php ----------
cat > "$ROOT/inc/footer.php" <<'PHP'
<?php declare(strict_types=1); $year = date('Y'); ?>
<footer class="border-t border-white/10 mt-16">
  <div class="max-w-6xl mx-auto px-4 py-10 grid sm:grid-cols-2 md:grid-cols-4 gap-8 text-sm">
    <div>
      <div class="flex items-center gap-2">
        <img src="/assets/logo.png" class="h-6 w-6 rounded ring-1 ring-white/10" alt="logo" />
        <span class="brand-quietgo text-lg">QuietGo</span>
      </div>
      <p class="mt-3 text-white/60">Educational patterns, privacy-first. Share insights, not photos.</p>
    </div>
    <div>
      <div class="font-medium text-white/80 mb-2">Product</div>
      <ul class="space-y-1">
        <li><a class="hover:text-white/90" href="/">Home</a></li>
        <li><a class="hover:text-white/90" href="/faq">FAQ</a></li>
        <li><a class="hover:text-white/90" href="/settings">Settings</a></li>
      </ul>
    </div>
    <div>
      <div class="font-medium text-white/80 mb-2">Company</div>
      <ul class="space-y-1">
        <li><a class="hover:text-white/90" href="/about">About</a></li>
        <li><a class="hover:text-white/90" href="/privacy">Privacy</a></li>
        <li><a class="hover:text-white/90" href="/terms">Terms</a></li>
      </ul>
    </div>
    <div>
      <div class="font-medium text-white/80 mb-2">Contact</div>
      <p class="text-white/70"><a class="underline" href="mailto:<?= SUPPORT_EMAIL ?>"><?= SUPPORT_EMAIL ?></a></p>
      <a href="<?= APP_STORE_URL ?>" class="inline-flex items-center gap-2 mt-3 text-white/80 hover:text-white">
        <img src="/assets/app-badge.png" class="h-6" alt="App Store" />
        <span>Get the app</span>
      </a>
    </div>
  </div>
  <div class="text-center text-xs text-white/50 py-4 border-t border-white/10">&copy; <?= $year ?> QuietGo. All rights reserved.</div>
</footer>
PHP

# ---------- inc/gate-modal.php ----------
cat > "$ROOT/inc/gate-modal.php" <<'PHP'
<?php declare(strict_types=1); ?>
<div id="gate" class="fixed inset-0 hidden items-center justify-center bg-black/70 p-4">
  <div class="card rounded-2xl max-w-md w-full p-6">
    <div class="flex items-center gap-3">
      <img src="/assets/app-icon.png" class="h-10 w-10 rounded-md" alt="app icon" />
      <div>
        <div class="font-semibold">Unlock sync with mobile subscription</div>
        <div class="text-white/60 text-sm">The web is a free demo. Full data sync unlocks with the iOS app.</div>
      </div>
    </div>
    <div class="mt-5 flex gap-3">
      <a href="<?= APP_STORE_URL ?>" class="px-4 py-2 rounded-md bg-teal-600 hover:bg-teal-500 text-white">Open App Store</a>
      <button data-close-gate class="px-4 py-2 rounded-md border border-white/10 hover:bg-white/5">Keep browsing</button>
    </div>
  </div>
</div>
PHP

# ---------- pages ----------
cat > "$ROOT/pages/home.php" <<'PHP'
<?php
$title = "QuietGo — Free Web Demo";
$desc  = "See patterns that matter. Web demo now; sync with mobile subscription.";
?>
<section class="max-w-6xl mx-auto px-4 py-14">
  <div class="grid md:grid-cols-2 gap-10 items-center">
    <div>
      <h1 class="text-3xl md:text-5xl font-semibold leading-tight"><span class="brand-quietgo">QuietGo</span> turns your plate into patterns.</h1>
      <p class="mt-5 text-white/70">Free web demo. Full sync with mobile subscription. Share insights, not photos.</p>
      <div class="mt-6 flex gap-3">
        <a href="#" data-open-gate class="px-5 py-2.5 rounded-md bg-teal-600 hover:bg-teal-500 text-white">Sync with iOS</a>
        <a href="#demo" class="px-5 py-2.5 rounded-md border border-white/10 hover:bg-white/5">See a demo</a>
      </div>
    </div>
    <div class="card rounded-2xl p-4">
      <img src="/assets/demo-dashboard.png" alt="Patterns dashboard demo" class="rounded-xl">
    </div>
  </div>
  <div class="mt-16 grid md:grid-cols-3 gap-6">
    <div class="card rounded-2xl p-6">
      <div class="text-lg font-semibold mb-2">Stool AI</div>
      <p class="text-white/70">Tasteful, non-graphic guidance based on the Bristol scale.</p>
    </div>
    <div class="card rounded-2xl p-6">
      <div class="text-lg font-semibold mb-2">Meal Photo AI <span class="text-xs ml-1 px-2 py-0.5 rounded bg-white/10">Add-On</span></div>
      <p class="text-white/70">Turn plate photos into foods, portions, and macros.</p>
    </div>
    <div class="card rounded-2xl p-6">
      <div class="text-lg font-semibold mb-2">Rhythm Reports</div>
      <p class="text-white/70">Printable PDF and CSV summaries that reveal your patterns.</p>
    </div>
  </div>
  <div id="demo" class="mt-16 grid md:grid-cols-2 gap-8">
    <div class="card rounded-2xl p-4">
      <img src="/assets/demo-rhythm.png" class="rounded-lg" alt="Rhythm report">
    </div>
    <div class="space-y-4">
      <img src="/assets/demo-stool.png" class="rounded-lg card p-2" alt="Stool AI mock" />
      <img src="/assets/demo-meal.png" class="rounded-lg card p-2" alt="Meal AI mock" />
    </div>
  </div>
  <div class="mt-16">
    <h2 class="text-2xl font-semibold mb-6">Pricing</h2>
    <div class="grid md:grid-cols-3 gap-6">
      <div class="card rounded-2xl p-6">
        <div class="text-lg font-semibold">Web Demo</div>
        <div class="text-3xl mt-2">$0</div>
        <p class="text-white/60 mt-2">Explore features and sample data.</p>
      </div>
      <div class="card rounded-2xl p-6 border-teal-600/40">
        <div class="text-lg font-semibold">Pro (Mobile)</div>
        <div class="text-3xl mt-2">${<?= PRO_MONTHLY ?>}/mo</div>
        <div class="text-white/60">or $<?= PRO_ANNUAL ?>/yr</div>
        <button data-open-gate class="mt-4 px-4 py-2 rounded-md bg-teal-600 hover:bg-teal-500 text-white">Subscribe on iOS</button>
      </div>
      <div class="card rounded-2xl p-6">
        <div class="text-lg font-semibold">Meal Photo AI (Add-On)</div>
        <div class="text-3xl mt-2">${<?= ADDON_MONTHLY ?>}/mo</div>
        <div class="text-white/60">or $<?= ADDON_ANNUAL ?>/yr</div>
      </div>
    </div>
  </div>
  <div class="mt-16 text-center">
    <p class="text-white/70">Stop guessing. Start seeing what drives your gut.</p>
  </div>
</section>
PHP

cat > "$ROOT/pages/about.php" <<'PHP'
<?php $title = "About — QuietGo"; ?>
<section class="max-w-4xl mx-auto px-4 py-14 space-y-8">
  <h1 class="text-3xl font-semibold"><span class="brand-quietgo">QuietGo</span> — Plate to Pattern</h1>
  <p class="text-white/70">Discreet, educational, privacy-first. The mobile app captures; the web reveals. Images are analyzed then auto-deleted by default.</p>
  <div class="grid md:grid-cols-3 gap-6">
    <div class="card rounded-2xl p-5"><div class="font-medium mb-2">Privacy</div><p class="text-white/70">Share insights, not photos. You control what’s shared.</p></div>
    <div class="card rounded-2xl p-5"><div class="font-medium mb-2">Patterns</div><p class="text-white/70">We surface rhythms and correlations in plain English.</p></div>
    <div class="card rounded-2xl p-5"><div class="font-medium mb-2">Ownership</div><p class="text-white/70">Exports in PDF/CSV. Your data, your choice.</p></div>
  </div>
</section>
PHP

cat > "$ROOT/pages/privacy.php" <<'PHP'
<?php $title = "Privacy — QuietGo"; ?>
<section class="max-w-4xl mx-auto px-4 py-14 space-y-6">
  <h1 class="text-3xl font-semibold">Privacy Policy</h1>
  <p class="text-white/70">Plain English summary. This web demo collects minimal analytics. Images in the mobile app are analyzed and then auto-deleted by default.</p>
  <h2 class="text-xl font-semibold mt-6">Data we collect</h2>
  <ul class="list-disc pl-5 text-white/70 space-y-2">
    <li>Account email and basic settings.</li>
    <li>Structured logs for troubleshooting (no raw photos).</li>
  </ul>
  <h2 class="text-xl font-semibold mt-6">Your controls</h2>
  <ul class="list-disc pl-5 text-white/70 space-y-2">
    <li>Sharing controls with link expiration.</li>
    <li>Export your data (PDF/CSV) as a subscriber.</li>
    <li>Request deletion via <a class="underline" href="mailto:<?= SUPPORT_EMAIL ?>"><?= SUPPORT_EMAIL ?></a>.</li>
  </ul>
  <p class="text-white/60 mt-6 text-sm">Educational use only. Not medical advice.</p>
</section>
PHP

cat > "$ROOT/pages/terms.php" <<'PHP'
<?php $title = "Terms — QuietGo"; ?>
<section class="max-w-4xl mx-auto px-4 py-14 space-y-6">
  <h1 class="text-3xl font-semibold">Terms of Service</h1>
  <p class="text-white/70">QuietGo is educational software and does not provide medical advice. Subscriptions are handled via Apple; refunds follow App Store policies.</p>
  <ul class="list-disc pl-5 text-white/70 space-y-2">
    <li>Acceptable use: no unlawful or harmful content.</li>
    <li>Exports: PDF/CSV available to subscribers.</li>
    <li>Uptime &amp; liability: provided “as is”.</li>
    <li>Jurisdiction &amp; contact: <a class="underline" href="mailto:<?= SUPPORT_EMAIL ?>"><?= SUPPORT_EMAIL ?></a></li>
  </ul>
</section>
PHP

cat > "$ROOT/pages/support.php" <<'PHP'
<?php $title = "Support — QuietGo"; ?>
<section class="max-w-3xl mx-auto px-4 py-14">
  <h1 class="text-3xl font-semibold">Support</h1>
  <p class="text-white/70">Email us: <a class="underline" href="mailto:<?= SUPPORT_EMAIL ?>"><?= SUPPORT_EMAIL ?></a></p>
  <form class="mt-8 grid gap-4 max-w-xl" method="post" action="/contact.php" novalidate>
    <input class="bg-black border border-white/10 rounded-md p-2" type="email" name="email" placeholder="you@example.com" required maxlength="120">
    <input class="bg-black border border-white/10 rounded-md p-2" type="text" name="subject" placeholder="Subject" required maxlength="120">
    <textarea class="bg-black border border-white/10 rounded-md p-3 h-40" name="message" placeholder="How can we help?" required maxlength="2000"></textarea>
    <input type="text" name="website" class="hidden" tabindex="-1" autocomplete="off">
    <button class="px-4 py-2 rounded-md bg-teal-600 hover:bg-teal-500 text-white" type="submit">Send</button>
  </form>
  <p class="text-white/50 text-xs mt-4">We reply within 1–2 business days.</p>
</section>
PHP

cat > "$ROOT/pages/faq.php" <<'PHP'
<?php $title = "FAQ — QuietGo"; ?>
<section class="max-w-4xl mx-auto px-4 py-14 space-y-6">
  <h1 class="text-3xl font-semibold">FAQ</h1>
  <details class="card rounded-xl p-4" open>
    <summary class="font-medium cursor-pointer">Is this medical?</summary>
    <p class="text-white/70 mt-2">Nope. QuietGo is educational. For medical advice, talk to your clinician.</p>
  </details>
  <details class="card rounded-xl p-4">
    <summary class="font-medium cursor-pointer">Do you store my photos?</summary>
    <p class="text-white/70 mt-2">Images are analyzed then auto-deleted by default. You control sharing and exports.</p>
  </details>
  <details class="card rounded-xl p-4">
    <summary class="font-medium cursor-pointer">How accurate is the AI?</summary>
    <p class="text-white/70 mt-2">It’s an estimate to help you notice patterns. You can edit or override at any time.</p>
  </details>
  <details class="card rounded-xl p-4">
    <summary class="font-medium cursor-pointer">How do I export?</summary>
    <p class="text-white/70 mt-2">Subscribers can export PDF/CSV from the dashboard. The web demo is read-only.</p>
  </details>
  <details class="card rounded-xl p-4">
    <summary class="font-medium cursor-pointer">What’s the Meal Photo AI add-on?</summary>
    <p class="text-white/70 mt-2">Auto-log foods, portions, and macros from a plate photo. Optional add-on.</p>
  </details>
</section>
PHP

cat > "$ROOT/pages/settings.php" <<'PHP'
<?php $title = "Settings — QuietGo"; ?>
<section class="max-w-3xl mx-auto px-4 py-14 space-y-6">
  <h1 class="text-3xl font-semibold">Settings</h1>
  <div class="card rounded-xl p-5 space-y-4 opacity-80">
    <label class="flex items-center gap-3">
      <input type="checkbox" checked disabled class="accent-teal-600">
      <span>Auto-delete images after analysis (default ON)</span>
    </label>
    <label class="flex items-center gap-3">
      <input type="checkbox" disabled class="accent-teal-600">
      <span>Share insights with a link (manage recipients)</span>
    </label>
    <label class="flex items-center gap-3">
      <input type="checkbox" disabled class="accent-teal-600">
      <span>Enable reminders</span>
    </label>
    <button data-open-gate class="px-4 py-2 rounded-md bg-white/5 border border-white/10">Save changes</button>
  </div>
</section>
PHP

cat > "$ROOT/pages/profile.php" <<'PHP'
<?php
$title = "Profile — QuietGo";
$plan = $_SESSION['demo'] ? "Demo" : "Pro";
?>
<section class="max-w-3xl mx-auto px-4 py-14 space-y-6">
  <h1 class="text-3xl font-semibold">Profile</h1>
  <div class="card rounded-xl p-5">
    <div class="grid sm:grid-cols-2 gap-4">
      <div><div class="text-white/60 text-sm">Plan</div><div class="text-lg"><?= $plan ?></div></div>
      <div><div class="text-white/60 text-sm">Add-On</div><div class="text-lg">Not enabled</div></div>
      <div><div class="text-white/60 text-sm">Manage</div><a class="underline" href="<?= APP_STORE_URL ?>">App Store</a></div>
      <div><div class="text-white/60 text-sm">Email</div><div class="text-lg"><?= SUPPORT_EMAIL ?></div></div>
    </div>
    <div class="mt-4">
      <button data-open-gate class="px-4 py-2 rounded-md bg-teal-600 hover:bg-teal-500 text-white">Upgrade</button>
    </div>
  </div>
</section>
PHP

# ---------- contact.php ----------
cat > "$ROOT/contact.php" <<'PHP'
<?php
declare(strict_types=1);
require __DIR__ . '/config.php';
$ok=false; $msg="Something went wrong.";
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $email = filter_input(INPUT_POST,'email',FILTER_VALIDATE_EMAIL);
  $subject = trim((string)($_POST['subject'] ?? ''));
  $message = trim((string)($_POST['message'] ?? ''));
  $honeypot = trim((string)($_POST['website'] ?? ''));
  $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
  if (!$email || strlen($subject)<3 || strlen($message)<5 || strlen($subject)>120 || strlen($message)>2000) {
    $msg="Please check your inputs and try again.";
  } elseif ($honeypot!=='') {
    $msg="Please try again.";
  } else {
    $now=time(); $last=$_SESSION['last_contact_time'] ?? 0;
    if ($now-$last<60) { $msg="Please wait a minute before sending another message."; }
    else {
      $_SESSION['last_contact_time']=$now;
      $headers="From: <$email>\r\nReply-To: $email\r\nContent-Type: text/plain; charset=UTF-8\r\n";
      $body="From: $email\nIP: $ip\n\nSubject: $subject\n\n$message\n";
      $ok = @mail(SUPPORT_EMAIL, "[QuietGo] $subject", $body, $headers);
      $msg = $ok ? "Thanks! We'll get back to you shortly." : "We couldn't send your message right now.";
    }
  }
}
$title = "Support — QuietGo";
?>
<section class="max-w-3xl mx-auto px-4 py-14">
  <h1 class="text-3xl font-semibold">Support</h1>
  <p class="mt-4 <?= $ok ? 'text-teal-400' : 'text-red-400' ?>"><?= htmlspecialchars($msg) ?></p>
  <p class="text-white/70 mt-2">Email us directly: <a class="underline" href="mailto:<?= SUPPORT_EMAIL ?>"><?= SUPPORT_EMAIL ?></a></p>
</section>
PHP

# ---------- js/site.js ----------
cat > "$ROOT/js/site.js" <<'JS'
(function(){
  const gate = document.getElementById('gate');
  function openGate(){ if(gate){ gate.classList.remove('hidden'); gate.classList.add('flex'); } }
  function closeGate(){ if(gate){ gate.classList.add('hidden'); gate.classList.remove('flex'); } }
  document.querySelectorAll('[data-open-gate]').forEach(el=>el.addEventListener('click', (e)=>{ e.preventDefault(); openGate(); }));
  document.querySelectorAll('[data-close-gate]').forEach(el=>el.addEventListener('click', (e)=>{ e.preventDefault(); closeGate(); }));
  try {
    const payload = { t: Date.now(), p: location.pathname, ua: navigator.userAgent.slice(0,120) };
    navigator.sendBeacon && navigator.sendBeacon('/beacon', new Blob([JSON.stringify(payload)], {type:'application/json'}));
  } catch(e){}
})();
JS

# ---------- assets/site.css ----------
cat > "$ROOT/assets/site.css" <<'CSS'
@media print {
  header, footer, #gate { display: none !important; }
  main { padding: 0 !important; }
  body { background: #fff !important; color: #000 !important; }
}
.brand-quietgo { text-rendering: optimizeLegibility; }
CSS

# ---------- placeholder notes ----------
cat > "README_QuietGo_Web.txt" <<'TXT'
Add your images to public_html/assets/:
  - logo.png          (your real logo; placeholder if missing)
  - og-cover.png
  - demo-dashboard.png
  - demo-stool.png
  - demo-meal.png
  - demo-rhythm.png
  - demo-rhythm.pdf   (optional; can skip for now)
  - app-badge.png
  - app-icon.png
  - favicon.ico
TXT

echo "Bootstrap complete: $ROOT created."
